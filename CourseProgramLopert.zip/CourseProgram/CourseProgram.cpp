//============================================================================
// Name        : CourseProgram.cpp
// Author      : Madison Lopert 
// Version     : 1.0
// Copyright   : Copyright � 2017 SNHU COCE
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <sstream>
#include <string>
#include <fstream>
#include <algorithm>

using namespace std;

//============================================================================
// Global definitions visible to all methods and classes
//============================================================================

// forward declarations
double strToDouble(string str, char ch);

// define a structure to hold course information
struct Course {
    // unique identifier
    string courseName;
    string courseNumber;
    string preReq1;
    string preReq2;
};

// Internal structure for tree node
struct Node {
    Course course;
    Node* left;
    Node* right;

    // default constructor
    Node() {
        left = nullptr;
        right = nullptr;
    }

    // initialize with a Course
    Node(Course aCourse) :
        Node() {
        course = aCourse;
    }
};

//============================================================================
// Binary Search Tree class definition for Course Project
//============================================================================

/**
 * Define a class containing data members and methods to
 * implement a binary search tree
 */
class CourseProgram {

private:
    Node* root;

    void addNode(Node* node, Course course);
    void printAlpha(Node* node);

public:
    CourseProgram();
    virtual ~CourseProgram();
    void PrintAlpha();
    void Insert(Course Course);
    Course Search(string courseNum);
    void loadCourses(CourseProgram* cTree);
};

/**
 * Default constructor
 */
CourseProgram::CourseProgram() {
    // FixMe (1): initialize housekeeping variables
    //root is equal to nullptr
    root = nullptr;
}

/**
 * Destructor
 */
CourseProgram::~CourseProgram() {
    // recurse from root deleting every node
}

/**
 * Traverse the tree in order
 */
void CourseProgram::PrintAlpha() {
    // call printAlpha fuction and pass root 
    printAlpha(root);
}


/**
 * Insert a Course
 */
void CourseProgram::Insert(Course Course) {
    // FIXME (5) Implement inserting a Course into the tree
    // if root equarl to null ptr
    if (root == nullptr) {
        // root is equal to new node Course
        root = new Node(Course);
    }
    else { // else
        // add Node root and Course
        addNode(root, Course);
    }


}
//Displays courses
void displayCourse(Course course) {
    cout << course.courseNumber << ", " << course.courseName << endl;
    if (!course.preReq1.empty() && course.preReq2.empty()) { //Number of prereq determines output
        cout << "Prerequisite: " << course.preReq1 << endl;
    }
    else if (!course.preReq1.empty() && !course.preReq2.empty()) {
        cout << "Prerequisites: " << course.preReq1 << " | " << course.preReq2 << endl;
    }
    else {
        cout << "Prerequisites: None" << endl;
    }
    return;
}

//Displays not found error
void displayError(string courseNum) { 
    cout << courseNum << " not found" << endl;
    return;
}

/**
 * Search for a Course
 */
Course CourseProgram::Search(string courseNum) {
    std::transform(courseNum.begin(), courseNum.end(), courseNum.begin(), ::toupper); //Set all input to upper case
    // set current node equal to root
    Node* current = root;
    Course course;
    bool match = false; //Use bool match to indicate if no match is found
    // keep looping downwards until bottom reached or matching CourseId found
    while (current != nullptr) {
        // if match found, return current Course
        if (current->course.courseNumber == courseNum) {
            match = true;
            displayCourse(current->course); //Call displayCourse to print found course
        }
        // if Course is smaller than current node then traverse left
        if (courseNum < current->course.courseNumber) {
            current = current->left;
        }
        // else larger so traverse right
        else {
            current = current->right;
        }
    }
    if (match == false) {
        displayError(courseNum); //call displayError to show match not found
    }
    return course;
}

/**
 * Add a Course to some node (recursive)
 *
 * @param node current node in tree
 * @param Course course to be added
 */
void CourseProgram::addNode(Node* node, Course Course) {
    // if node is larger then add to left
    if (node->course.courseNumber > Course.courseNumber) {
        // if no left node
        if (node->left == nullptr) {
            // this node becomes left
            node->left = new Node(Course);
        }
        // else recurse down the left node
        else {
            addNode(node->left, Course);
        }
    }
    else { // else
        if (node->right == nullptr) { // if no right node
            // this node becomes right
            node->right = new Node(Course);
        }
        else {
            addNode(node->right, Course); // else recurse down the right node
        }
    }

}

//prints list of courses names and numbers. Binary trees sort alphanumerically 
void CourseProgram::printAlpha(Node* node) {
    //if node is not equal to null ptr
    if (node != nullptr) {
        printAlpha(node->left);
        //output Course Number, Course Name
        cout << node->course.courseNumber << ", " << node->course.courseName << endl;
        printAlpha(node->right); 

    }
}

//Load courses and assign them 
void loadCourses(CourseProgram* cTree) {
    Course course;
    cout << "Loading data structure " << endl;
    ifstream file("ABCU_Advising_Program_Input.txt");
    Course* root = NULL;
    if (!file.is_open()) {
        cout << "Unable to open ABCU_Advising_Program_Input.txt file\n";
        exit(0);
    }
    string line;

    //cout << "Hi. Testing above" << endl;
    while (getline(file, line)) {
        stringstream ss(line);
        //Amount of commas per line indicates amount of prerequistes 
        std::string::difference_type commaTimes = std::count(line.begin(), line.end(), ',');
        if (commaTimes == 1) {
            getline(ss, course.courseNumber, ',');
            getline(ss, course.courseName, ',');
            course.preReq1 = "";
            course.preReq2 = "";
        }
        else if (commaTimes == 2) {
            getline(ss, course.courseNumber, ',');
            getline(ss, course.courseName, ',');
            getline(ss, course.preReq1, ',');
            course.preReq2 = "";
        }
        if (commaTimes == 3) {
            getline(ss, course.courseNumber, ',');
            getline(ss, course.courseName, ',');
            getline(ss, course.preReq1, ',');
            getline(ss, course.preReq2, ',');
        }
        cTree->Insert(course);
    }
    file.close();
}

/**
 * The one and only main() method
 */
int main() {

    // process command line arguments
    Course course;
    CourseProgram* cTree;
    cTree = new CourseProgram();


    int choice = 0;
    string courseInput = "";
    while (choice != 9) {
        cout << "Welcome to the course planner." << endl;
        cout << "  1. Load Data Structure" << endl;
        cout << "  2. Print Course List" << endl;
        cout << "  3. Print Course" << endl;
        cout << "  9. Exit" << endl;
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {

        case 1:
            loadCourses(cTree);
            break;

        case 2:
            cTree->PrintAlpha();
            break;

        case 3:
            cout << "What course would you like to know about? ";
            cin >> courseInput;
            cTree->Search(courseInput);
            break;

        case 9:
            cout << "Thank you for using the course planner!" << endl;
            return 0;
        default:
            cout << choice << " is not a valid option" << endl;

            break;
        }
    
    }

}
